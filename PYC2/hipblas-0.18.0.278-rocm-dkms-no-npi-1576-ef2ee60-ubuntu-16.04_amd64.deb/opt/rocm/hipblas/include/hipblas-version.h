/* ************************************************************************
 * Copyright 2016 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/* the configured version and settings
 */
#define hipblasVersionMajor @hipblas_VERSION_MAJOR @
#define hipblaseVersionMinor @hipblas_VERSION_MINOR @
#define hipblasVersionPatch @hipblas_VERSION_PATCH @
#define hipblasVersionTweak @hipblas_VERSION_TWEAK @
