var searchData=
[
  ['gl_5fdim3',['gl_dim3',['../structgl__dim3.html',1,'']]],
  ['grid_5flaunch_5fparm',['grid_launch_parm',['../structgrid__launch__parm.html',1,'']]],
  ['groupid',['GroupId',['../structhip__impl_1_1GroupId.html',1,'hip_impl']]],
  ['groupsize',['GroupSize',['../structhip__impl_1_1GroupSize.html',1,'hip_impl']]]
];
