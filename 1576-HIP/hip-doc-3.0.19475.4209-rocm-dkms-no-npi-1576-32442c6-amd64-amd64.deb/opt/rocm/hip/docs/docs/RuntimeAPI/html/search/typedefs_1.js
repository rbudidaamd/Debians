var searchData=
[
  ['hipfunccache_5ft',['hipFuncCache_t',['../group__GlobalDefs.html#ga7effbca2af70714feaa3330bf1a77a72',1,'hip_runtime_api.h']]],
  ['hipsharedmemconfig',['hipSharedMemConfig',['../group__GlobalDefs.html#ga6b1ca424fa26a5fb718937d662eaee7f',1,'hip_runtime_api.h']]],
  ['hipstreamcallback_5ft',['hipStreamCallback_t',['../group__Stream.html#ga6d4e90ec5736f9728102be22d0559dfd',1,'hip_runtime_api.h']]],
  ['hipsurfaceobject_5ft',['hipSurfaceObject_t',['../hip__surface__types_8h.html#a8e399424af12e04be293a525f1159857',1,'hip_surface_types.h']]]
];
