var searchData=
[
  ['numgroups',['NumGroups',['../structhip__impl_1_1NumGroups.html',1,'hip_impl']]]
];
