var searchData=
[
  ['uchar2holder',['uchar2Holder',['../structuchar2Holder.html',1,'']]],
  ['ucharholder',['ucharHolder',['../structucharHolder.html',1,'']]]
];
