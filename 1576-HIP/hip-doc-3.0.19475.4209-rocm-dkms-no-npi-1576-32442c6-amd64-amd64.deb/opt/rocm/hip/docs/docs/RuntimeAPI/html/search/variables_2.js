var searchData=
[
  ['barrier_5fbit',['barrier_bit',['../structgrid__launch__parm.html#aad0a298878d5e27e9575e59022925425',1,'grid_launch_parm']]],
  ['blockdim',['blockDim',['../structhipLaunchParams__t.html#af6ac9253cfc205e4c96684abc5a8d338',1,'hipLaunchParams_t']]]
];
