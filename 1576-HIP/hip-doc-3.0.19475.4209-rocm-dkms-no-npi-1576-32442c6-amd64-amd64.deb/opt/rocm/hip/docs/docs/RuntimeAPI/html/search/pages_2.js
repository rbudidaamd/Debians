var searchData=
[
  ['heterogeneous_2dcomputing_20interface_20for_20portability_20_28hip_29',['Heterogeneous-computing Interface for Portability (HIP)',['../index.html',1,'']]]
];
