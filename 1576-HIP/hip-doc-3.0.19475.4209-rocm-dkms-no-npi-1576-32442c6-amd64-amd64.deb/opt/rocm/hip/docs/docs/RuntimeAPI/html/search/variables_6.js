var searchData=
[
  ['func',['func',['../structhipLaunchParams__t.html#abd19544799affe641d0875f18f0d7212',1,'hipLaunchParams_t']]]
];
