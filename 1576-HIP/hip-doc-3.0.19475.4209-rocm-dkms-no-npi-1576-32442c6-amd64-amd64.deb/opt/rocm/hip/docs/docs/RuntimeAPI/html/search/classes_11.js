var searchData=
[
  ['y',['Y',['../structCoordinates_1_1Y.html',1,'Coordinates']]]
];
