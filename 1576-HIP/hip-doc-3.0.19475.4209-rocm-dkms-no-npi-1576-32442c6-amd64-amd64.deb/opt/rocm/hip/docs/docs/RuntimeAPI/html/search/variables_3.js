var searchData=
[
  ['canmaphostmemory',['canMapHostMemory',['../structhipDeviceProp__t.html#ac2143f5448607d1a02a9e8783fcf06a1',1,'hipDeviceProp_t']]],
  ['cf',['cf',['../structgrid__launch__parm.html#aeea7233f3f08322d31fe89731110e997',1,'grid_launch_parm']]],
  ['clockinstructionrate',['clockInstructionRate',['../structhipDeviceProp__t.html#a6fbf3b08a1a08ae700f1a06265f6666b',1,'hipDeviceProp_t']]],
  ['clockrate',['clockRate',['../structhipDeviceProp__t.html#a1dd15bee43692b8649dfbdc1adbaaf96',1,'hipDeviceProp_t']]],
  ['computemode',['computeMode',['../structhipDeviceProp__t.html#ae7d9216f8583a703359d0b9373823f5d',1,'hipDeviceProp_t']]],
  ['concurrentkernels',['concurrentKernels',['../structhipDeviceProp__t.html#ad8461a28caf9c38c58cf358583b5bee3',1,'hipDeviceProp_t']]],
  ['cooperativelaunch',['cooperativeLaunch',['../structhipDeviceProp__t.html#a7e99d56223ca8e08a3b0281a8dc07a46',1,'hipDeviceProp_t']]],
  ['cooperativemultidevicelaunch',['cooperativeMultiDeviceLaunch',['../structhipDeviceProp__t.html#a4d4e0cfcd887d072f28e5f37643fe239',1,'hipDeviceProp_t']]]
];
