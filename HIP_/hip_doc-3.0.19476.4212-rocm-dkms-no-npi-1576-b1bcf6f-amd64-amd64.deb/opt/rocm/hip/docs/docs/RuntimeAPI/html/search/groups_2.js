var searchData=
[
  ['error_20handling',['Error Handling',['../group__Error.html',1,'']]],
  ['event_20management',['Event Management',['../group__Event.html',1,'']]]
];
