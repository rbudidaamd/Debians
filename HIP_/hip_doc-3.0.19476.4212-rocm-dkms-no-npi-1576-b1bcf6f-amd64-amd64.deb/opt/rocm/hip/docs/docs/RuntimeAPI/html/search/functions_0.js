var searchData=
[
  ['_5f_5fhippopcallconfiguration',['__hipPopCallConfiguration',['../group__Clang.html#ga06210258503eaac9eb89d26015484774',1,'hip_runtime_api.h']]],
  ['_5f_5fhippushcallconfiguration',['__hipPushCallConfiguration',['../group__Clang.html#ga11d34c41b6af50bda5da678949191dfd',1,'hip_runtime_api.h']]]
];
