var searchData=
[
  ['vgprallocgranule',['VGPRAllocGranule',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a719d60a14c4f8d786b3ba768fc921ea7',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]]
];
